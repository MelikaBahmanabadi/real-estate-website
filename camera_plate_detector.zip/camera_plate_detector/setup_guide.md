# License Plate Detection API

A FastAPI-based web service for detecting and recognizing Iranian license plates in images using computer vision and machine learning.

## Features

- **Single Image Processing**: Detect license plates in individual images
- **Batch Processing**: Process multiple images simultaneously
- **Visualization**: Get detection results with visual annotations
- **Real-time Processing**: Fast inference with configurable confidence thresholds
- **RESTful API**: Easy integration with web applications and mobile apps
- **CORS Support**: Cross-origin requests enabled for web frontends

## Requirements

### Dependencies

```bash
pip install fastapi uvicorn python-multipart
pip install opencv-python pillow numpy
pip install pydantic typing-extensions
```

### Model Files

The API requires the following model files in the specified directories:

- `./models/plate_detection.pt` - YOLOv8 model for license plate detection
- `./models/char_Recognition.pt` - YOLOv8 model for character recognition
- `./data.yaml` - Character class configuration file

### Custom Module

- `plate_recognition.py` - Contains the `PlatePipeline` and `PlatePrediction` classes

## Installation

1. **Clone the repository**
```bash
git clone https://azuredevops.ime.co.ir/ICT-Collection/Intelligent-Systems/_git/car-plate-detector
cd license-plate-api
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Download model files**
   - Place your trained models in the `./models/` directory
   - Ensure `data.yaml` is in the root directory

4. **Run the API**
```bash
python main.py
```

The API will be available at `http://localhost:8000`

## API Endpoints

### Health Check
```http
GET /health
```
Check if the service is running and models are loaded.

### Single Image Detection
```http
POST /detect
```
**Parameters:**
- `file` (required): Image file (JPG, PNG, etc.)
- `plate_conf` (optional): Plate detection confidence threshold (default: 0.5)
- `char_conf` (optional): Character recognition confidence threshold (default: 0.3)
- `include_cropped_images` (optional): Include base64 encoded cropped plate images

**Response:**
```json
{
  "success": true,
  "message": "Successfully detected 1 plate(s)",
  "plates_count": 1,
  "plates": [
    {
      "bbox_xyxy": [100, 150, 300, 200],
      "plate_conf": 0.95,
      "pred_text": "12ص345678",
      "char_count": 8,
      "p1": "12",
      "p2": "ص",
      "p3": "345",
      "p4": "67",
      "cropped_image_base64": "base64_string..."
    }
  ],
  "processing_time": 0.234
}
```

### Detection with Visualization
```http
POST /detect_with_visualization
```
Same parameters as `/detect`, but returns an additional visualization image with bounding boxes and recognized text.

### Batch Processing
```http
POST /detect_batch
```
**Parameters:**
- `files`: Multiple image files (max 10 files)

Process multiple images in a single request.

### API Documentation
```http
GET /docs
```
Interactive Swagger UI documentation.

## Usage Examples

### Python Client Example

```python
import requests

# Single image detection
with open('car_image.jpg', 'rb') as f:
    files = {'file': f}
    data = {'plate_conf': 0.6, 'char_conf': 0.4}
    response = requests.post('http://localhost:8000/detect', files=files, data=data)
    result = response.json()
    
print(f"Detected {result['plates_count']} plates")
for plate in result['plates']:
    print(f"Plate: {plate['pred_text']} (confidence: {plate['plate_conf']:.2f})")
```

### JavaScript/Fetch Example

```javascript
const formData = new FormData();
formData.append('file', fileInput.files[0]);
formData.append('plate_conf', '0.6');

fetch('http://localhost:8000/detect', {
    method: 'POST',
    body: formData
})
.then(response => response.json())
.then(data => {
    console.log('Detection results:', data);
});
```

### cURL Example

```bash
curl -X POST "http://localhost:8000/detect" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@car_image.jpg" \
     -F "plate_conf=0.6" \
     -F "char_conf=0.4"
```

## Response Format

### Plate Parts Explanation

Iranian license plates are parsed into 4 parts:
- `p1`: First 2 digits
- `p2`: Letter (Persian character)
- `p3`: Middle 3 digits  
- `p4`: Last 2 digits

Example: "12ص34567" → p1="12", p2="ص", p3="345", p4="67"

### Error Responses

```json
{
  "detail": "Error message describing what went wrong"
}
```

Common HTTP status codes:
- `400`: Bad request (invalid image format, parameters)
- `500`: Internal server error (processing failed)
- `503`: Service unavailable (models not loaded)

## Configuration

### Model Configuration

Edit the pipeline initialization in the code:

```python
pipeline = PlatePipeline(
    plate_detector_weights="./models/plate_detection.pt",
    char_detector_weights="./models/char_Recognition.pt",
    char_data_yaml="./data.yaml",
    plate_conf=0.5,        # Default plate confidence
    char_conf=0.3,         # Default character confidence
    char_iou=0.5,          # IoU threshold for NMS
    char_imgsz=320,        # Character detection image size
    device="cpu",          # Use "cuda" for GPU
    max_chars=8,           # Maximum characters per plate
)
```

### Server Configuration

```python
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host="0.0.0.0",    # Listen on all interfaces
        port=8000,         # Port number
        workers=1          # Number of worker processes
    )
```

## Performance Notes

- **CPU vs GPU**: Set `device="cuda"` for GPU acceleration
- **Batch Size**: Limited to 10 images per batch request
- **Image Size**: Larger images take more processing time
- **Memory**: GPU models require adequate VRAM

## Error Handling

The API includes comprehensive error handling for:
- Invalid image formats
- Model loading failures
- Processing timeouts
- Invalid parameters
- File size limits

## Development

### Adding New Features

1. **Custom confidence thresholds per request**
2. **Additional output formats** (XML, CSV)
3. **Image preprocessing options**
4. **Webhook notifications for batch processing**
5. **Database integration for result storage**

### Testing

```bash
# Test health endpoint
curl http://localhost:8000/health

# Test with sample image
curl -X POST -F "file=@test_image.jpg" http://localhost:8000/detect
```

## License

[Add your license information here]

## Support

For issues and questions:
- Check the `/docs` endpoint for API documentation
- Review error messages in the response
- Enable logging for detailed debugging information

---
