1. Run `python .\main.py`
2. In second terminal run `python .\camera_plate_detector.py`