from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import cv2
import numpy as np
from PIL import Image
import io
import os
import tempfile
import base64
from pathlib import Path
import logging

# Import your existing pipeline
from plate_recognition import PlatePipeline, PlatePrediction

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="License Plate Detection API",
    description="API for detecting and recognizing license plates in images",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Response models
class PlateDetectionResponse(BaseModel):
    bbox_xyxy: List[int]
    plate_conf: float
    pred_text: str
    char_count: int
    p1: str  # First part (digits)
    p2: str  # Letter part
    p3: str  # Third part (digits)
    p4: str  # Fourth part (digits)
    cropped_image_base64: Optional[str] = None  # Add this field

class DetectionResult(BaseModel):
    success: bool
    message: str
    plates_count: int
    plates: List[PlateDetectionResponse]
    processing_time: Optional[float] = None

class HealthResponse(BaseModel):
    status: str
    message: str

# Global pipeline instance
pipeline: Optional[PlatePipeline] = None

def initialize_pipeline():
    """Initialize the plate detection pipeline"""
    global pipeline
    try:
        pipeline = PlatePipeline(
            plate_detector_weights=r"./models/plate_detection.pt",
            plate_class_name="کل ناحیه پلاک",
            char_detector_weights=r"./models/char_Recognition.pt",
            char_data_yaml=r"./data.yaml",
            plate_conf=0.5,
            char_conf=0.3,
            char_iou=0.5,
            char_imgsz=320,
            device="cpu",
            max_chars=8,
        )
        logger.info("Pipeline initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize pipeline: {str(e)}")
        raise e

@app.on_event("startup")
async def startup_event():
    """Initialize the pipeline on startup"""
    initialize_pipeline()

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    if pipeline is None:
        return HealthResponse(status="unhealthy", message="Pipeline not initialized")
    return HealthResponse(status="healthy", message="Service is running")

def process_image_from_bytes(image_bytes: bytes) -> np.ndarray:
    """Convert uploaded image bytes to OpenCV format"""
    try:
        # Convert bytes to PIL Image
        image = Image.open(io.BytesIO(image_bytes))
        
        # Convert PIL to OpenCV format (BGR)
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # PIL uses RGB, OpenCV uses BGR
        opencv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        return opencv_image
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image format: {str(e)}")

def parse_plate_parts(digits_str: str, letter_str: str) -> Dict[str, str]:
    """Parse plate parts according to Iranian license plate format"""
    digit_list = digits_str.split(" ") if digits_str else []
    
    # Initialize all parts
    parts = {"p1": "", "p2": letter_str, "p3": "", "p4": ""}
    
    if len(digit_list) >= 2:
        parts["p1"] = digit_list[0] + digit_list[1]
    elif len(digit_list) == 1:
        parts["p1"] = digit_list[0]
    
    if len(digit_list) >= 5:
        parts["p3"] = digit_list[2] + digit_list[3] + digit_list[4]
    elif len(digit_list) >= 3:
        parts["p3"] = "".join(digit_list[2:])
    
    if len(digit_list) >= 7:
        parts["p4"] = digit_list[5] + digit_list[6]
    elif len(digit_list) == 6:
        parts["p4"] = digit_list[5]
    
    return parts

@app.post("/detect", response_model=DetectionResult)
async def detect_plates(
    file: UploadFile = File(...),
    plate_conf: Optional[float] = Form(0.5),
    char_conf: Optional[float] = Form(0.3),
    include_cropped_images: Optional[bool] = Form(False)  # Add this parameter
):
    """
    Detect and recognize license plates in an uploaded image
    
    - **file**: Image file (jpg, png, etc.)
    - **plate_conf**: Confidence threshold for plate detection (0.1-1.0)
    - **char_conf**: Confidence threshold for character recognition (0.1-1.0)
    """
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Service not available. Pipeline not initialized.")
    
    # Validate file
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        import time
        start_time = time.time()
        
        # Read image
        image_bytes = await file.read()
        image_bgr = process_image_from_bytes(image_bytes)
        
        # Update pipeline confidence if provided
        if plate_conf != pipeline.plate_conf:
            pipeline.plate_conf = plate_conf
        if char_conf != pipeline.char_conf:
            pipeline.char_conf = char_conf
        
        # Run prediction
        predictions = pipeline.predict(image_bgr)
        
        processing_time = time.time() - start_time
        
        # Format results
        plates_data = []
        for pred in predictions:
            digits_str, letter_str, _ = pipeline.format_plate_simple(pred.pred_class_ids)
            parts = parse_plate_parts(digits_str, letter_str)
            x1, y1, x2, y2 = map(int, pred.plate_bbox_xyxy)
            cropped_plate = image_bgr[y1:y2, x1:x2]
            success, buffer = cv2.imencode('.jpg', cropped_plate, [cv2.IMWRITE_JPEG_QUALITY, 85])
            cropped_image_base64 = base64.b64encode(buffer).decode('utf-8')
            
            plate_response = PlateDetectionResponse(
                bbox_xyxy=list(pred.plate_bbox_xyxy),
                plate_conf=pred.plate_conf,
                pred_text=pred.pred_text,
                char_count=pred.char_count,
                p1=parts["p1"],
                p2=parts["p2"],
                p3=parts["p3"],
                p4=parts["p4"],
                cropped_image_base64 = cropped_image_base64
            )
            plates_data.append(plate_response)
        
        return DetectionResult(
            success=True,
            message=f"Successfully detected {len(predictions)} plate(s)",
            plates_count=len(predictions),
            plates=plates_data,
            processing_time=round(processing_time, 3)
        )
        
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.post("/detect_with_visualization")
async def detect_plates_with_visualization(
    file: UploadFile = File(...),
    plate_conf: Optional[float] = Form(0.5),
    char_conf: Optional[float] = Form(0.3)
):
    """
    Detect license plates and return both results and visualization
    """
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Service not available. Pipeline not initialized.")
    
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Read and process image
        image_bytes = await file.read()
        image_bgr = process_image_from_bytes(image_bytes)
        
        # Update confidence thresholds
        if plate_conf != pipeline.plate_conf:
            pipeline.plate_conf = plate_conf
        if char_conf != pipeline.char_conf:
            pipeline.char_conf = char_conf
        
        # Run prediction
        predictions = pipeline.predict(image_bgr)
        
        # Create visualization
        vis_image = pipeline.visualize_on_image(image_bgr, predictions)
        
        # Convert visualization to base64
        _, buffer = cv2.imencode('.jpg', vis_image)
        img_base64 = base64.b64encode(buffer).decode('utf-8')
        
        # Format plate data
        plates_data = []
        for pred in predictions:
            digits_str, letter_str, _ = pipeline.format_plate_simple(pred.pred_class_ids)
            parts = parse_plate_parts(digits_str, letter_str)
            
            plate_response = PlateDetectionResponse(
                bbox_xyxy=list(pred.plate_bbox_xyxy),
                plate_conf=pred.plate_conf,
                pred_text=pred.pred_text,
                char_count=pred.char_count,
                p1=parts["p1"],
                p2=parts["p2"],
                p3=parts["p3"],
                p4=parts["p4"]
            )
            plates_data.append(plate_response)
        
        return {
            "success": True,
            "message": f"Successfully detected {len(predictions)} plate(s)",
            "plates_count": len(predictions),
            "plates": plates_data,
            "visualization": f"data:image/jpeg;base64,{img_base64}"
        }
        
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.post("/detect_batch")
async def detect_plates_batch(files: List[UploadFile] = File(...)):
    """
    Process multiple images at once
    """
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Service not available. Pipeline not initialized.")
    
    if len(files) > 10:  # Limit batch size
        raise HTTPException(status_code=400, detail="Maximum 10 files allowed per batch")
    
    results = []
    
    for file in files:
        if not file.content_type.startswith("image/"):
            results.append({
                "filename": file.filename,
                "success": False,
                "error": "Not an image file"
            })
            continue
        
        try:
            image_bytes = await file.read()
            image_bgr = process_image_from_bytes(image_bytes)
            predictions = pipeline.predict(image_bgr)
            
            plates_data = []
            for pred in predictions:
                digits_str, letter_str, _ = pipeline.format_plate_simple(pred.pred_class_ids)
                parts = parse_plate_parts(digits_str, letter_str)
                
                plate_response = PlateDetectionResponse(
                    bbox_xyxy=list(pred.plate_bbox_xyxy),
                    plate_conf=pred.plate_conf,
                    pred_text=pred.pred_text,
                    char_count=pred.char_count,
                    p1=parts["p1"],
                    p2=parts["p2"],
                    p3=parts["p3"],
                    p4=parts["p4"]
                )
                plates_data.append(plate_response)
            
            results.append({
                "filename": file.filename,
                "success": True,
                "plates_count": len(predictions),
                "plates": plates_data
            })
            
        except Exception as e:
            results.append({
                "filename": file.filename,
                "success": False,
                "error": str(e)
            })
    
    return {"results": results}

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "License Plate Detection API",
        "version": "1.0.0",
        "endpoints": {
            "/health": "Health check",
            "/detect": "Single image detection",
            "/detect_with_visualization": "Detection with visualization",
            "/detect_batch": "Batch processing",
            "/docs": "API documentation"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
