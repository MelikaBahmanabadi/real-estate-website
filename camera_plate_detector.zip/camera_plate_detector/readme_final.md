# 🚗🤖 Vehicle & License Plate Detection System

> **Scope**: End‑to‑end detection and recognition of Iranian vehicle license plates (cars & motorcycles) using YOLOv8.

---

## 📌 Overview

This project implements a **two‑stage computer vision pipeline**:

1. **Vehicle & Plate Detection** – Locate vehicles and license plates in images.

2. **Character Recognition (OCR)** – Detect and classify digits and Persian characters on plates.

The system is designed for **real‑world parking and street scenarios**, supporting:

- Moving & parked vehicles

- Multiple vehicles per image

- Diverse Iranian plate types (general, taxi, police, government, military, ceremonial, etc.)

---

## 🧠 System Architecture

```
Input Image
   │
   ▼
Vehicle Detection (YOLOv8)
   │
   ▼
Plate Detection
   │
   ▼
Character Detection (YOLOv8 – OCR)
   │
   ▼
Structured Plate Output (JSON)
```

> 📎 **Design principle**: modular, debuggable, and dataset‑driven.

---

## 📊 Dataset Description

### 🔹 Synthetic Dataset

- **40,000** synthetic Iranian plates

- Generated via: iranian-license-plate-generator

- Balanced character distribution

### 🔹 Real‑World Dataset

Captured from street cameras with challenging conditions:

- Motion blur

- Occlusions

- Multiple vehicles

- Varying lighting (day/night)

#### Dataset Cleaning Summary

| Split         | Raw Images | After Review | Retention |
| ------------- | ---------- | ------------ | --------- |
| 🟦 Train      | 45,469     | 43,628       | 96%       |
| 🟨 Validation | 5,413      | 5,127        | 95%       |
| 🟥 Test       | 5,602      | 4,773        | 85%       |

> ⚠️ Images were manually reviewed for **label correctness and visibility**.

---

## 📈 Final Dataset Composition

Merged synthetic + real datasets:

| Split         | Images     | Percentage |
| ------------- | ---------- | ---------- |
| 🟦 Train      | 65,469     | 70%        |
| 🟨 Validation | 18,705     | 20%        |
| 🟥 Test       | 9,354      | 10%        |
| **Total**     | **93,528** | **100%**   |

---

## 📂 Project Structure

### 🧩 Data Preparation

| Script                      | Purpose                             |
| --------------------------- | ----------------------------------- |
| `xml_to_json_for_plate.py`  | Convert plate labels (XML → JSON)   |
| `xml_to_json_for_car.py`    | Convert vehicle labels (XML → JSON) |
| `json_to_yolo_for_plate.py` | JSON → YOLO format (plates)         |
| `json_to_yolo_for_car.py`   | JSON → YOLO format (vehicles)       |
| `train_val_split.py`        | Dataset splitting                   |

---

### 🔍 Visualization & Analysis

| Script                        | Insight                        |
| ----------------------------- | ------------------------------ |
| `draw_bbox_for_plate.py`      | Visualize plate bounding boxes |
| `draw_bbox_for_car.py`        | Visualize car & plate boxes    |
| `analyze_labels_from_json.py` | Object & character statistics  |
| `merge_label_stats.py`        | Character frequency balancing  |

---

### 🧪 Integrity & Utilities

| Script                     | Description                    |
| -------------------------- | ------------------------------ |
| `compare_two_directory.py` | Hash‑based duplicate detection |

---

## 🏋️ Model Training

### Training Configuration (YOLOv8)

```python
model = YOLO("yolov8n.pt")
model.train(
  data="data.yaml",
  imgsz=320,
  epochs=200,
  batch=16,
  lr0=1e-3,
  hsv_h=0.02,
  hsv_s=0.20,
  hsv_v=0.25,
  degrees=25,
  scale=0.10,
  mosaic=0.5,
  fliplr=0.5,
  translate=0.1,
  patience=30,
  device=0,
  resume=False
)
```

### 🎛️ Key Augmentations

| Augmentation | Purpose                     |
| ------------ | --------------------------- |
| HSV tuning   | Day/Night simulation        |
| Rotation     | Camera angle robustness     |
| Mosaic       | Multi‑object generalization |
| Flip         | Orientation diversity       |

---

## 🔁 Training Resume Strategy

| Scenario          | Configuration                  |
| ----------------- | ------------------------------ |
| Fresh training    | `resume=False` + `yolov8n.pt`  |
| Continue training | `resume=True` + `last.pt`      |
| Best inference    | Load `best.pt` (higher mAP@95) |

---

## 🧪 Model Evaluation

- Script: `test_model.py`

- Metrics:

  - mAP@50

  - mAP@50:95

  - Precision / Recall

> 📊 Recommended: visualize confusion matrix for OCR stage.

---

## 🔠 Character Mapping (OCR)

- **Total classes**: 40

- **Includes**:

  - Digits (0‑9)

  - Persian letters

  - Special plate tokens (e.g. تشریفات)

> Stored in `real_data.yaml`

```YAML
path: yolo_char
train: images/train
val: images/val
nc: 40
names:
  0: "0"
  1: "1"
  2: "2"
  3: "3" 
  4: "4"
  5: "5"
  6: "6"
  7: "7"
  8: "8"
  9: "9"
  10: "الف"
  11: "ب"
  12: "پ"
  13: "ت"
  14: "ث"
  15: "ج"
  16: "د"
  17: "ز"
  18: "س"
  19: "ش"
  20: "ص"
  21: "ض"
  22: "ط"
  23: "ظ"
  24: "ع"
  25: "ف"
  26: "ق"
  27: "ک"
  28: "گ"
  29: "ل"
  30: "م"
  31: "ن"
  32: "و"
  33: "ه"
  34: "ی"
  35: "d"
  36: "s"
  37: "ژ"
  38: "تشریفات"
  39: "ح"
```

> Stored in `real_data.yaml`

---

## 📸 Qualitative Results (Model Outputs)

> All images below are **real inference outputs** from the trained YOLOv8 pipeline.
> Bounding boxes indicate detected license plates; labels show predicted plate IDs.

---

### 🌙 Night Scenarios

| Low Illumination | Headlight Glare |
| ---------------- | --------------- |
| <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_low_illumination.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_low_illumination.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a></p> | <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_headlight_glare.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_headlight_glare.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/><a></p> |

| Motion Blur | Urban Parking |
| ----------- | ------------- |
| <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_motion_blur.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_motion_blur.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a></p> | <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_urban_parking.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/night_urban_parking.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/><a></p> |

**Observations (Night):**

- Robust detection despite strong headlight saturation

- Stable plate localization under sensor noise

- Acceptable OCR accuracy even with partial blur

---

### ☀️ Day Scenarios

| Dense Traffic |
| ------------- |
| <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_dense_traffic_01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_dense_traffic_01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a> &nbsp;&nbsp; <a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_dense_traffic_02.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_dense_traffic_02.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a></p> |

| Special Vehicles |
| ---------------- |
| <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/special_veichle_01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/special_veichle_01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a> &nbsp;&nbsp; <a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/special_veichle_02.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/special_veichle_02.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a></p> |

| Perspective Distortion |
| ---------------------- |
| <p align="center"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_perspective_distortion01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/day_perspective_distortion01.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a> |

**Observations (Day):**

- Accurate plate detection across varying distances

- Handles multiple plates per frame reliably

- Perspective distortion has limited impact on recall

---

## 🧪 Qualitative Evaluation Summary

| Scenario Type           | Detection Quality | OCR Stability | Notes                              |
| ----------------------- | ----------------- | ------------- | ---------------------------------- |
| Night – Low Light       | 🟢 High           | 🟡 Medium     | Noise affects character confidence |
| Night – Headlight Glare | 🟢 High           | 🟡 Medium     | Bounding boxes remain stable       |
| Day – Dense Traffic     | 🟢 High           | 🟢 High       | Best overall performance           |
| Day – Long Range        | 🟡 Medium         | 🟡 Medium     | Small plates reduce OCR accuracy   |
| Partial Occlusion       | 🟡 Medium         | 🔴 Low        | Expected failure mode              |

> ✅ Overall, the system demonstrates **strong real-world robustness**, with predictable and explainable degradation under extreme conditions.

---

## 🚀 Inference Pipeline

`plate_pipeline_json.py`

**Inputs**:

- Image directory

- Trained `.pt` model

- `real_data.yaml`

**Outputs**:

- Bounding boxes

- Character predictions

- JSON‑structured plate result

---

## 📎 API & Sample Template (Mock)

> ⚠️ The following section is **sample only** and not production‑ready.

```http
GET /api/items
GET /api/items/{id}
```

---

## 🧰 Tech Stack

| Layer      | Tools             |
| ---------- | ----------------- |
| CV         | YOLOv8, OpenCV    |
| Language   | Python            |
| Training   | Ultralytics       |
| Annotation | XML → JSON → YOLO |

---

## 🧩 Key Features

- ✅ Multi‑vehicle detection

- ✅ Persian OCR support

- ✅ Dataset deduplication

- ✅ Modular pipeline

- ✅ Augmentation‑rich training

---

## 📌 Lessons Learned

- Synthetic + real data **significantly improves generalization**

- OCR accuracy is **data‑distribution sensitive**

- Label quality > dataset size

---

## 👤 Teams

- **[Ali Sadeghi-Aghili](https://github.com/alisadeghiaghili)**

- MohammadReza Gahtarani

- **[Melika Bahman-Abadi](https://github.com/MelikaBahmanabadi)**

## 👤 Author

- **[Melika Bahman-Abadi](https://github.com/MelikaBahmanabadi)**

## 📚 References & Credits

- YOLOv8 Documentation

- [Iranian License Plate Generator](https://github.com/barzansaeedpour/iranian-license-plate-generator)

---

## 🏷️ License & Badges
<p align="left"><a href="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/logo.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0"><img src="https://azuredevops.ime.co.ir/ICT-Collection/4cbe21ce-d7a0-46b4-bab6-26360a8db5d3/_apis/git/repositories/9562e5bc-403d-4cc2-ab26-191421525dd2/items?path=/readme_images/logo.jpg&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=api_develop&resolveLfs=true&%24format=octetStream&api-version=5.0" width="300"/></a>


## 📝 Appendix

Additional diagrams, confusion matrices, and dataset statistics