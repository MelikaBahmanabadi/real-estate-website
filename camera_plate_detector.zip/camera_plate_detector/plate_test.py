import requests
import os

# --- Configuration ---
BASE_URL = "http://localhost:8000"
SINGLE_IMAGE_PATH = r"D:\projects\car_plate\test_image\0b2ffbec-85a8-4dc1-9b10-ceb12b20c9b0.webp"

def test_health_endpoint():
    """Tests the /health endpoint."""
    print("\n--- Testing /health ---")
    try:
        response = requests.get(f"{BASE_URL}/health")
        response.raise_for_status() # Raises HTTPError for bad responses (4xx or 5xx)
        print(f"Health Status: {response.json()}")
    except requests.exceptions.RequestException as e:
        print(f"Error accessing /health: {e}")

def test_detect_single_plate():
    """Tests the /detect endpoint with a single file and custom conf."""
    if not os.path.exists(SINGLE_IMAGE_PATH):
        print(f"\nSkipping /detect: Single image not found at '{SINGLE_IMAGE_PATH}'. Please update the SINGLE_IMAGE_PATH variable.")
        return

    print("\n--- Testing /detect (Single Image) ---")
    
    # 1. Prepare the files and data for POST request
    files = {
        'file': (os.path.basename(SINGLE_IMAGE_PATH), 
                 open(SINGLE_IMAGE_PATH, 'rb'), 
                 'image/jpeg')
    }
    # Optional: Send custom configuration parameters as form data
    data = {
        'plate_conf': '0.75',
        'char_conf': '0.4'
    }

    try:
        response = requests.post(
            f"{BASE_URL}/detect", 
            files=files, 
            data=data
        )
        response.raise_for_status()
        print("Detection Successful.")
        
        result = response.json()
        print(result)
        print(f"Plates Found: {result.get('plates_count')}")
        # Display the first plate's recognized text
        if result.get('plates'):
            print(f"First Plate Text: {result['plates'][0].get('text')}")
            # Print the parsed parts if available
            if result['plates'][0].get('parsed_parts'):
                 print(f"Parsed Parts: {result['plates'][0]['parsed_parts']}")

    except requests.exceptions.HTTPError as e:
        print(f"HTTP Error on /detect (Status {response.status_code}): {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Connection Error on /detect: {e}")
    finally:
        # Close the file handles opened in 'files'
        for f in files.values():
            f[1].close()


if __name__ == "__main__":
    print("Starting Python tests...")
    
    test_health_endpoint()
    test_detect_single_plate()
    
    
    print("\nTesting complete.")
