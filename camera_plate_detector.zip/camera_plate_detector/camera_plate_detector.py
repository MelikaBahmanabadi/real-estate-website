import cv2
import os
import time
import requests
import typer

from rich.console import Console
from rich.panel import Panel

# Initialize
app = typer.Typer(help="📸 Camera + License Plate Recognition")
console = Console()

# --------------------------------------------------
# Configuration
# --------------------------------------------------

API_URL = "http://localhost:8000/detect"

DEFAULT_OUTPUT_DIR = "captures"

PLATE_CONF = 0.75
CHAR_CONF = 0.4

REQUEST_TIMEOUT = 30


# --------------------------------------------------
# API
# --------------------------------------------------

def detect_plate(image_path: str):
    """
    Send an image to the license plate detection API.
    """

    try:
        with open(image_path, "rb") as image_file:

            files = {
                "file": (
                    os.path.basename(image_path),
                    image_file,
                    "image/jpeg"
                )
            }

            data = {
                "plate_conf": str(PLATE_CONF),
                "char_conf": str(CHAR_CONF),
            }

            response = requests.post(
                API_URL,
                files=files,
                data=data,
                timeout=REQUEST_TIMEOUT
            )

        response.raise_for_status()

        return response.json()

    except requests.exceptions.ConnectionError:
        console.print(
            "[bold red]✘ Cannot connect to Plate Detection API.[/bold red]"
        )
        console.print(
            f"[dim]Make sure the API is running at {API_URL}[/dim]"
        )

    except requests.exceptions.Timeout:
        console.print(
            "[bold red]✘ Plate Detection API request timed out.[/bold red]"
        )

    except requests.exceptions.HTTPError as e:
        console.print(
            f"[bold red]✘ API HTTP error:[/bold red] {e}"
        )

        if e.response is not None:
            console.print(
                f"[dim]{e.response.text}[/dim]"
            )

    except requests.exceptions.RequestException as e:
        console.print(
            f"[bold red]✘ API request failed:[/bold red] {e}"
        )

    except Exception as e:
        console.print(
            f"[bold red]✘ Unexpected error:[/bold red] {e}"
        )

    return None


# --------------------------------------------------
# Plate formatting
# --------------------------------------------------

def format_plate(plate: dict) -> str:
    """
    Format Iranian license plate parts returned by the API.
    """

    p1 = plate.get("p1", "")
    p2 = plate.get("p2", "")
    p3 = plate.get("p3", "")
    p4 = plate.get("p4", "")

    return f"{p1} | {p2} | {p3} | {p4}"


# --------------------------------------------------
# Process captured image
# --------------------------------------------------

def process_image(image_path: str):
    """
    Send a captured image to the plate recognition API
    and print the recognition result.
    """

    console.print(
        f"\n[dim]→ Sending image to plate detection API:[/dim] "
        f"{image_path}"
    )

    result = detect_plate(image_path)

    if result is None:
        return

    plates_count = result.get("plates_count", 0)

    # --------------------------------------------------
    # No plate detected
    # --------------------------------------------------

    if plates_count == 0:
        console.print(
            "[bold yellow]⚠ Plate not detected.[/bold yellow]"
        )
        return

    # --------------------------------------------------
    # Plate detected
    # --------------------------------------------------

    console.print(
        f"[bold green]✔ {plates_count} plate(s) detected.[/bold green]"
    )

    plates = result.get("plates", [])

    for index, plate in enumerate(plates, start=1):

        plate_text = format_plate(plate)

        plate_conf = plate.get("plate_conf", 0)
        char_count = plate.get("char_count", 0)

        console.print(
            f"[bold cyan]Plate {index}:[/bold cyan] "
            f"{plate_text}"
        )

        console.print(
            f"  [dim]Confidence: {plate_conf:.3f} | "
            f"Characters: {char_count}[/dim]"
        )


# --------------------------------------------------
# Camera
# --------------------------------------------------

@app.command()
def start(
    output_dir: str = typer.Option(
        DEFAULT_OUTPUT_DIR,
        "--dir",
        "-d",
        help="Directory to save captured images"
    ),
    cam_index: int = typer.Option(
        0,
        "--cam",
        "-c",
        help="Camera index"
    )
):
    """
    Start camera and recognize license plates
    when S is pressed.
    """

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Open camera
    cap = cv2.VideoCapture(cam_index)

    if not cap.isOpened():
        console.print(
            "[bold red]✘ Error:[/bold red] Could not open camera."
        )
        raise typer.Exit(code=1)

    console.print(
        Panel(
            "Camera Active\n\n"
            "Press [bold]S[/bold] to capture and recognize plate\n"
            "Press [bold]Q[/bold] to quit",
            title="License Plate Recognition",
            style="bold green"
        )
    )

    try:

        while True:

            ret, frame = cap.read()

            if not ret:
                console.print(
                    "[bold red]✘ Failed to read frame from camera.[/bold red]"
                )
                break

            # Display camera
            cv2.imshow("License Plate Camera", frame)

            # Wait for key
            key = cv2.waitKey(1) & 0xFF

            # --------------------------------------------------
            # Capture image
            # --------------------------------------------------

            if key == ord("s") or key == ord("S"):

                timestamp = time.strftime(
                    "%Y%m%d-%H%M%S"
                )

                filename = f"capture_{timestamp}.jpg"

                image_path = os.path.join(
                    output_dir,
                    filename
                )

                # Save image
                success = cv2.imwrite(
                    image_path,
                    frame
                )

                if not success:
                    console.print(
                        "[bold red]✘ Failed to save image.[/bold red]"
                    )
                    continue

                console.print(
                    f"\n[bold cyan]✔ Image saved:[/bold cyan] "
                    f"{image_path}"
                )

                # Run plate detection
                process_image(image_path)

            # --------------------------------------------------
            # Quit
            # --------------------------------------------------

            elif key == ord("q") or key == ord("Q"):
                break

    finally:

        cap.release()
        cv2.destroyAllWindows()

        console.print(
            "\n[yellow]Camera stopped.[/yellow]"
        )


# --------------------------------------------------
# Entry point
# --------------------------------------------------

if __name__ == "__main__":
    app()
