from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import cv2
import yaml
from ultralytics import YOLO

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import json



# =========================
# Data structures
# =========================
@dataclass
class PlateDetection:
    bbox_xyxy: Tuple[int, int, int, int]  # (x1,y1,x2,y2) on the street image
    conf: float
    crop_bgr: Any  # numpy array (BGR)


@dataclass
class PlatePrediction:
    plate_bbox_xyxy: Tuple[int, int, int, int]
    plate_conf: float
    plate_crop_bgr: Any  # numpy array (BGR)
    pred_class_ids: List[int]  # predicted class ids from char model (ordered L->R)
    pred_text: str             # safe string: "digits | letter"
    char_count: int            # number of detected chars (<= max_chars)


# =========================
# Pipeline class
# =========================
class PlatePipeline:
    """
    Two-stage pipeline:
      1) Detect plates in a street image (multiple cars => multiple plates)
      2) For each plate crop, predict characters

    Extra:
      - Directory mode: process all images in a folder
      - Saves:
          * visualized images
          * YOLO labels (plate boxes) per image
          * text summary per image (digits + letter separated to avoid RTL/LTR confusion)
    """

    IMG_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp")

    def __init__(
        self,
        plate_detector_weights: str,
        plate_class_name: str,
        char_detector_weights: str,
        char_data_yaml: str,
        plate_conf: float = 0.5,
        char_conf: float = 0.3,
        char_iou: float = 0.5,
        char_imgsz: int = 320,
        device: Union[str, int] = "cpu",
        max_chars: int = 8,
    ):
        # plate detector
        self.plate_model = YOLO(plate_detector_weights)
        self.plate_class_name = plate_class_name
        self.plate_conf = plate_conf

        # char detector
        self.char_model = YOLO(char_detector_weights)
        self.char_conf = char_conf
        self.char_iou = char_iou
        self.char_imgsz = char_imgsz
        self.device = device
        self.max_chars = max_chars

        # class map for chars
        self.class_id_to_name = self._load_class_map_from_yaml(char_data_yaml)

    # -------------------------
    # YAML class map
    # -------------------------
    @staticmethod
    def _load_class_map_from_yaml(yaml_path: str) -> Dict[int, str]:
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        names = data.get("names", {})
        class_map: Dict[int, str] = {}

        if isinstance(names, dict):
            for k, v in names.items():
                class_map[int(k)] = str(v)
        elif isinstance(names, list):
            for i, v in enumerate(names):
                class_map[i] = str(v)

        return class_map

    # -------------------------
    # Plate detection
    # -------------------------
    def detect_plates(self, image_bgr: Any) -> List[PlateDetection]:
        if image_bgr is None:
            return []

        h, w = image_bgr.shape[:2]

        results = self.plate_model.predict(
            source=image_bgr,
            conf=self.plate_conf,
            verbose=False,
        )
        r = results[0]

        dets: List[PlateDetection] = []
        if r.boxes is None:
            return dets

        for box in r.boxes:
            class_id = int(box.cls)
            class_name = r.names.get(class_id, str(class_id))

            if class_name != self.plate_class_name:
                continue

            x1, y1, x2, y2 = box.xyxy[0].tolist()
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

            # clamp
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w, x2), min(h, y2)
            if x2 <= x1 or y2 <= y1:
                continue

            crop = image_bgr[y1:y2, x1:x2]
            if crop is None or crop.size == 0:
                continue

            conf = float(box.conf[0]) if hasattr(box, "conf") else 0.0
            dets.append(PlateDetection(bbox_xyxy=(x1, y1, x2, y2), conf=conf, crop_bgr=crop))

        return dets

    # -------------------------
    # Char prediction on one plate crop
    # -------------------------
    def predict_plate_chars(self, plate_crop_bgr: Any) -> List[int]:
        """
        Returns ordered class_ids from left to right.
        Keeps only top max_chars by confidence, then sorts L->R.
        """
        if plate_crop_bgr is None or plate_crop_bgr.size == 0:
            return []

        results = self.char_model.predict(
            source=plate_crop_bgr,
            conf=self.char_conf,
            iou=self.char_iou,
            imgsz=self.char_imgsz,
            device=self.device,
            verbose=False,
            save=False,
        )
        r = results[0]
        if r.boxes is None:
            return []

        boxes = r.boxes
        cls = boxes.cls.detach().cpu().numpy().astype(int)
        confs = boxes.conf.detach().cpu().numpy()
        xyxy = boxes.xyxy.detach().cpu().numpy()

        idxs = list(range(len(cls)))
        if len(idxs) > self.max_chars:
            idxs = sorted(idxs, key=lambda i: confs[i], reverse=True)[: self.max_chars]

        dets = []
        for i in idxs:
            x1, _, x2, _ = xyxy[i]
            xc = (x1 + x2) / 2.0
            dets.append((xc, int(cls[i])))

        dets.sort(key=lambda x: x[0])  # left -> right
        return [cid for _, cid in dets]

    # -------------------------
    # Safe formatting (avoid RTL/LTR mess)
    # -------------------------
    def format_plate_simple(self, class_ids: List[int]) -> Tuple[str, str, str]:
        tokens = [
            self.class_id_to_name.get(cid, f"UNK{cid}")
            for cid in class_ids
        ]

        digits = [t for t in tokens if t.isdigit()]
        letters = [t for t in tokens if not t.isdigit()]

        digits_str = " ".join(digits)
        letter_str = " ".join(letters)

        if digits_str and letter_str:
            combined = f"{digits_str} | {letter_str}"
        elif digits_str:
            combined = digits_str
        else:
            combined = letter_str

        return digits_str, letter_str, combined


    # -------------------------
    # Full predict for one image
    # -------------------------
    def predict(self, image: Union[str, Any]) -> List[PlatePrediction]:
        if isinstance(image, str):
            image_bgr = cv2.imread(image)
            if image_bgr is None:
                raise ValueError(f"Could not read image: {image}")
        else:
            image_bgr = image

        plates = self.detect_plates(image_bgr)

        preds: List[PlatePrediction] = []
        for p in plates:
            char_ids = self.predict_plate_chars(p.crop_bgr)
            _, _, combined = self.format_plate_simple(char_ids)

            preds.append(
                PlatePrediction(
                    plate_bbox_xyxy=p.bbox_xyxy,
                    plate_conf=p.conf,
                    plate_crop_bgr=p.crop_bgr,
                    pred_class_ids=char_ids,
                    pred_text=combined,
                    char_count=len(char_ids),
                )
            )
        return preds
    @staticmethod
    def _draw_text_pil(img_bgr, text, x, y, font_path, font_size=20):
        # BGR -> RGB
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(img_rgb)
        draw = ImageDraw.Draw(pil_img)
        font = ImageFont.truetype(font_path, font_size)
        draw.text((x, y), text, font=font, fill=(0, 255, 0))  # RGB green
        # RGB -> BGR
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    # -------------------------
    # Visualization on street image
    # -------------------------
    def visualize_on_image(
        self,
        image_bgr: Any,
        preds: List[PlatePrediction],
        font_path: str = r"C:\Windows\Fonts\tahoma.ttf",
        font_size: int = 20,
        thickness: int = 2,
    ) -> Any:
        img = image_bgr.copy()

        # boxes
        for pr in preds:
            x1, y1, x2, y2 = pr.plate_bbox_xyxy
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), thickness)

        # text (PIL)
        for pr in preds:
            x1, y1, _, _ = pr.plate_bbox_xyxy
            label = f"{pr.pred_text} ({pr.char_count})"
            y_text = max(0, y1 - (font_size + 6))
            img = self._draw_text_pil(img, label, x1, y_text, font_path, font_size)

        return img


    # -------------------------
    # Saving helpers
    # -------------------------
    @staticmethod
    def _xyxy_to_yolo_line(
        cls_id: int, x1: int, y1: int, x2: int, y2: int, img_w: int, img_h: int
    ) -> str:
        bw = max(1, x2 - x1)
        bh = max(1, y2 - y1)
        xc = x1 + bw / 2.0
        yc = y1 + bh / 2.0
        return f"{cls_id} {xc/img_w:.6f} {yc/img_h:.6f} {bw/img_w:.6f} {bh/img_h:.6f}"

    # -------------------------
    # Directory mode
    # -------------------------
    def predict_directory(
        self,
        img_dir: str,
        vis_outdir: str,
        yolo_labels_outdir: str,
        plates_text_outdir: str,
        plates_json_outdir: str,
        plate_cls_id_for_label: int = 0,
    ):
        """
        For each image in img_dir:
          - predicts all plates
          - saves visualized image to vis_outdir
          - saves YOLO labels of detected plates to yolo_labels_outdir (one txt per image)
          - saves predicted plate texts to plates_text_outdir (one txt per image)
        """
        os.makedirs(vis_outdir, exist_ok=True)
        os.makedirs(yolo_labels_outdir, exist_ok=True)
        os.makedirs(plates_text_outdir, exist_ok=True)
        os.makedirs(plates_json_outdir, exist_ok=True)

        images = sorted(
            f for f in os.listdir(img_dir)
            if f.lower().endswith(self.IMG_EXTS)
        )

        for fn in images:
            img_path = os.path.join(img_dir, fn)
            stem = os.path.splitext(fn)[0]

            img = cv2.imread(img_path)
            if img is None:
                print(f"[WARN] Could not read: {img_path}")
                continue

            preds = self.predict(img)

            # ---- Save visualization
            vis_img = self.visualize_on_image(img, preds, font_path=r"C:\Windows\Fonts\tahoma.ttf", font_size=20)

            vis_path = os.path.join(vis_outdir, f"{stem}.jpg")
            cv2.imwrite(vis_path, vis_img)

            # ---- Save YOLO labels for plate boxes (on street image)
            h, w = img.shape[:2]
            label_path = os.path.join(yolo_labels_outdir, f"{stem}.txt")
            with open(label_path, "w", encoding="utf-8") as f:
                for pr in preds:
                    x1, y1, x2, y2 = pr.plate_bbox_xyxy
                    f.write(self._xyxy_to_yolo_line(plate_cls_id_for_label, x1, y1, x2, y2, w, h) + "\n")

            # ---- Save predicted plate texts (digits + letter separated)
            text_path = os.path.join(plates_text_outdir, f"{stem}.txt")
            json_path = os.path.join(plates_json_outdir, f"{stem}.json")

            with open(text_path, "w", encoding="utf-8") as f:
                f.write(f"image: {img_path}\n")
                f.write(f"plates: {len(preds)}\n\n")
                for i, pr in enumerate(preds, 1):
                    x1, y1, x2, y2 = pr.plate_bbox_xyxy
                    digits_str, letter_str, combined = self.format_plate_simple(pr.pred_class_ids)
                    f.write(
                        f"[{i}] bbox=({x1},{y1},{x2},{y2}) "
                        f"plate_conf={pr.plate_conf:.3f} "
                        f"char_count={pr.char_count} "
                        f"DIGITS={digits_str} "
                        f"LETTER={letter_str} "
                        f"COMBINED={combined}\n"
                    )
            with open(json_path, "w", encoding="utf-8") as f:
                for i, pr in enumerate(preds, 1):
                    x1, y1, x2, y2 = pr.plate_bbox_xyxy
                    digits_str, letter_str, combined = self.format_plate_simple(pr.pred_class_ids)
                    digit_list = digits_str.split(" ")
                    
                    zero_digit_partition = ""
                    first_digit_partition = ""
                    second_digit_partition = ""
                    third_digit_partition = ""
                    fourth_digit_partition = ""
                    fifth_digit_partition = ""
                    sixth_digit_partition = ""  

                    if len(digit_list) ==7 and letter_str !=None:
                        zero_digit_partition = digits_str.split(" ")[0]
                        first_digit_partition = digits_str.split(" ")[1]
                        second_digit_partition = digits_str.split(" ")[2]
                        third_digit_partition = digits_str.split(" ")[3]
                        fourth_digit_partition = digits_str.split(" ")[4]
                        fifth_digit_partition = digits_str.split(" ")[5]
                        sixth_digit_partition = digits_str.split(" ")[6]   

                        data = {
                         "image": img_path,
                         "p1" : zero_digit_partition + first_digit_partition,
                         "p2" : letter_str,
                         "p3" : second_digit_partition + third_digit_partition +fourth_digit_partition,
                         "p4" : fifth_digit_partition + sixth_digit_partition 
                        }

                        json.dump(data, f, ensure_ascii=False, indent=2)
                    
                    else:
                        data = {
                         "image": img_path,
                         "error" : "Plate not detected."
                        }

                        json.dump(data, f, ensure_ascii=False, indent=2)

                   
            print(f"[OK] {fn}: plates={len(preds)} | vis={vis_path} | labels={label_path} | text={text_path}")


# =========================
# Example usage (directory mode)
# =========================
if __name__ == "__main__":
    pipeline = PlatePipeline(
        plate_detector_weights="./models/car_plate_detector.pt",
        plate_class_name="کل ناحیه پلاک",
        char_detector_weights=r"./models/14041017-e100/best.pt",
        char_data_yaml=r"./real_data.yaml",
        plate_conf=0.5,
        char_conf=0.3,
        char_iou=0.5,
        char_imgsz=320,
        device="cpu",
        max_chars=8,
    )

    IMG_DIR = r"E:\local\AIProjects\car-plate-detection\dataset\CAR\2\car_img-test\test"
    VIS_OUT = r"E:\local\AIProjects\car-plate-detection\dataset\CAR\2\car_img-test\test\prediction\vis"
    LAB_OUT = r"E:\local\AIProjects\car-plate-detection\dataset\CAR\2\car_img-test\test\prediction\labels"
    TXT_OUT = r"E:\local\AIProjects\car-plate-detection\dataset\CAR\2\car_img-test\test\prediction\plates_text"
    JSON_OUT = r"E:\local\AIProjects\car-plate-detection\dataset\CAR\2\car_img-test\test\prediction\plates_json"

    pipeline.predict_directory(
        img_dir=IMG_DIR,
        vis_outdir=VIS_OUT,
        yolo_labels_outdir=LAB_OUT,
        plates_text_outdir=TXT_OUT,
        plates_json_outdir=JSON_OUT,
        plate_cls_id_for_label=0,
    )
